/*
Aluno: Hevellyn Karinne Ribeiro Castro
Turma: 2° informatica
 exercicio 34
 */
import java.util.Scanner;
public class exc34 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double x, f;
        System.out.println("qual o valor de x");
        x = input.nextDouble();
        f = 8/(2-x);
        System.out.println("o resultado e "+f);
    }
}
